import Bot from "../utils/vk.js";

export async function sendCode(request, response){
 Bot(12345)
    console.log('work')

}