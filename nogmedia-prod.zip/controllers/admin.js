export async function setPost(req, res) {
	console.log(req.body);
	res.send([1])
}